package com.howtodoinjava.example;
 
import java.util.Set;
 
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
 
import com.howtodoinjava.example.model.User;
 
public class TestHibernateValidator
{
    public static void main(String[] args)
    {
    	/*
    	 * 
    	 * Java example to use hibernate validator to validate Java bean fields. Bean validation API 2 (JSR-380)
    	 *  offers some popular annotations that can be attached to each bean property for the purpose of
    	 *  maintaining data integrity.
    	 *  
    	 *  
    	 */
    	
    	
        //Create ValidatorFactory which returns validator
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
         
        //It validates bean instances
        Validator validator = factory.getValidator();
 
        User user = new User(null, "1", "abcgmail.com");
 
        //Validate bean
        Set<ConstraintViolation<User>> constraintViolations = validator.validate(user);
 
        //Show errors
        if (constraintViolations.size() > 0) {
            for (ConstraintViolation<User> violation : constraintViolations) {
                System.out.println(violation.getMessage());
            }
        } else {
            System.out.println("Valid Object");
        }
    }
}